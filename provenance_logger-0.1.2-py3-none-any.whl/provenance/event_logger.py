from datetime import datetime
from typing import Optional, List, Literal, Union
from pydantic import BaseModel
from neo4j import GraphDatabase

# Neo4j connection settings
NEO4J_URI = "bolt://ec2-18-133-186-21.eu-west-2.compute.amazonaws.com:7687"
NEO4J_USER = "neo4j"
NEO4J_PASSWORD = "c1pd3moproject"

# Base class for all provenance events
class BaseEvent(BaseModel):
    record_id: str
    type: str
    timestamp: datetime
    sha256: str
    previous_record: Optional[str]
    trace_id: Optional[str]

# Specific event types
class AssetRegistered(BaseEvent):
    type: Literal['AssetRegistered'] = 'AssetRegistered'
    said: str
    owner_spid: str
    asset_type: Literal["dataset", "model"]  # "dataset" or "model"
    usage_rights: str
    creator_spid: Optional[str]
    creator_scid: Optional[str]
    creator_ssid: Optional[str]

class ServiceRequested(BaseEvent):
    type: Literal['ServiceRequested'] = 'ServiceRequested'
    requestor_spid: str
    requestee_spid: str
    requestee_scid: Union[List[str], str]

class AgreementProposed(BaseEvent):
    type: Literal['AgreementProposed'] = 'AgreementProposed'
    requestor_spid: str
    requestee_spid: Union[List[str], str]
    agreement_id: str
    source_said: str
    version: str
    status: str
    created_at: datetime
    existing_license: Optional[str]
    usage_rights: str
    sow: str

class AgreementModified(BaseEvent):
    type: Literal['AgreementModified'] = 'AgreementModified'
    requestor_spid: str
    requestee_spid: Union[List[str], str]
    parent_agreement_id: str
    source_said: str
    version: str
    status: str
    updated_at: datetime
    existing_license: Optional[str]
    usage_rights: str
    sow: str

class AgreementSigned(BaseEvent):
    type: Literal['AgreementSigned'] = 'AgreementSigned'
    requestor_spid: str
    requestee_spid: Union[List[str], str]
    parent_agreement_id: str
    source_said: str
    version: str
    status: Literal['ACCEPTED'] = 'ACCEPTED'
    updated_at: datetime
    existing_license: Optional[str]
    usage_rights: str
    sow: str

class DataPrepServiceStarted(BaseEvent):
    type: Literal['DataPrepServiceStarted'] = 'DataPrepServiceStarted'
    scid: str
    provider_spid: str
    requestor_spid: Union[List[str], str]

class DataPrepServiceFinished(BaseEvent):
    type: Literal['DataPrepServiceFinished'] = 'DataPrepServiceFinished'
    scid: str
    provider_spid: str
    requestor_spid: Union[List[str], str]

class SessionStarted(BaseEvent):
    type: Literal['SessionStarted'] = 'SessionStarted'
    ssid: str
    scid: str
    spid: Union[List[str], str]

class SessionEnded(BaseEvent):
    type: Literal['SessionEnded'] = 'SessionEnded'
    ssid: str
    scid: str
    spid: Union[List[str], str]

class AssetAccessed(BaseEvent):
    type: Literal['AssetAccessed'] = 'AssetAccessed'
    said: str
    owner_spid: str
    accessor_spid: Union[List[str], str]
    accessor_scid: str
    accessor_ssid: str

class DataTransformed(BaseEvent):
    type: Literal['DataTransformed'] = 'DataTransformed'
    said: str
    accessor_spid: str
    accessor_scid: str
    accessor_ssid: str
    transforms: Union[List[str], str]

class Neo4jLogger:
    def __init__(self, uri: str, user: str, password: str):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))

    def close(self):
        self.driver.close()

    def log_event(self, event):
        """Logs an event to Neo4j and links it properly in the provenance chain."""
        try:
            with self.driver.session() as session:
                session.write_transaction(self._create_event_node, event)
            print(f"Successfully logged {event.type} with ID {event.record_id}")
        except Exception as e:
            print(f"Failed to log event {event.type}: {e}")

    @staticmethod
    def _create_event_node(tx, event):
        query = (
            f"CREATE (e:Event:{event.type} {{"
            "name: $type, record_id: $record_id, type: $type, timestamp: $timestamp, sha256: $sha256, trace_id: $trace_id"
        )
        params = {
            "record_id": event.record_id,
            "type": event.type,
            "timestamp": event.timestamp.isoformat(),
            "sha256": event.sha256,
            "name": event.type,
            "trace_id": event.trace_id
        }
        
        for key, value in event.dict().items():
            if key not in params:
                query += f", {key}: ${key}"
                params[key] = value
        
        query += "})"
        relationship_query = ""
    
    # Link Event Nodes with ID Nodes    
        spids = set(filter(None, [
            getattr(event, "owner_spid", None),
            getattr(event, "requestor_spid", None),
            getattr(event, "requestee_spid", None),
            getattr(event, "spid", None)
        ]))
        if spids:
            for i, spid in enumerate(spids):
                params[f"spid_{i}"] = spid
                relationship_query += (
                    f" WITH e OPTIONAL MATCH (sp{i}:ServiceProvider {{spid: $spid_{i}}})"
                    f" FOREACH (ignoreMe IN CASE WHEN sp{i} IS NOT NULL THEN [1] ELSE [] END | CREATE (e)-[:INVOLVES]->(sp{i}))"
                     )

        # Ensure ServiceAsset exists and link event to it
        if hasattr(event, "said"):
            params["said"] = event.said
            relationship_query += (
                " WITH e OPTIONAL MATCH (sa:ServiceAsset {said: $said})"
                " FOREACH (ignoreMe IN CASE WHEN sa IS NOT NULL THEN [1] ELSE [] END | CREATE (e)-[:AFFECTS]->(sa))"
            )

        # Ensure ServiceComponent exists and link event to it
        if hasattr(event, "scid"):
            params["scid"] = event.scid
            relationship_query += (
                " WITH e OPTIONAL MATCH (sc:ServiceComponent {scid: $scid})"
                " FOREACH (ignoreMe IN CASE WHEN sc IS NOT NULL THEN [1] ELSE [] END | CREATE (e)-[:USES]->(sc))"
            )

        # Ensure ServiceSchedule exists and link event to it
        if hasattr(event, "ssid"):
            params["ssid"] = event.ssid
            relationship_query += (
                " WITH e OPTIONAL MATCH (ss:ServiceSchedule {ssid: $ssid})"
                " FOREACH (ignoreMe IN CASE WHEN ss IS NOT NULL THEN [1] ELSE [] END | CREATE (e)-[:EXECUTES]->(ss))"
            )


        # Chain continuation logic
        if event.previous_record:
            relationship_query += (
                " WITH e MATCH (prev:Event {record_id: $previous_record}) "
                " CREATE (prev)-[:NEXT]->(e)"
            )
            params["previous_record"] = event.previous_record
        else:
            relationship_query += (
                " WITH e"
                " OPTIONAL MATCH (prev:Event) "
                " WHERE prev.trace_id = e.trace_id"
                " AND prev.record_id <> e.record_id "
                " WITH e, prev ORDER BY prev.timestamp DESC LIMIT 1 "
                " FOREACH (ignoreMe IN CASE WHEN prev IS NOT NULL THEN [1] ELSE [] END | CREATE (prev)-[:NEXT]->(e)) "
            )

        # Special case: Link new AssetRegistered to old AssetRegistered
        # if event.type == "AssetRegistered" and event.creator_spid:
        #     relationship_query += (
        #         " WITH e"
        #         " OPTIONAL MATCH (dt:Event:DataTransformed) "
        #         " WHERE dt.accessor_spid = $creator_spid "
        #         " WITH e, dt "
        #         " OPTIONAL MATCH (orig:Event:AssetRegistered) "
        #         " WHERE orig.owner_spid = $creator_spid "
        #         " WITH e, dt, orig "
        #         # " FOREACH (ignoreMe IN CASE WHEN dt IS NOT NULL THEN [1] ELSE [] END | CREATE (dt)-[:RESULTED_IN]->(e)) "
        #         " FOREACH (ignoreMe IN CASE WHEN orig IS NOT NULL THEN [1] ELSE [] END | CREATE (e)-[:DERIVED_FROM]->(orig)) "
        #     )
        #     params["creator_spid"] = event.creator_spid
                
        full_query = query + relationship_query
        tx.run(full_query, **params)

# Logger instance
_logger = Neo4jLogger(NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD)

def log_event(event: BaseModel):
    """Function to log events."""
    _logger.log_event(event)

def close_logger():
    """Close the Neo4j connection when the system shuts down."""
    _logger.close()
