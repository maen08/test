import uuid
import time
import pandas as pd
from src.provenance.logger import log_provenance_event

def transform_text(data: pd.Series, pipeline_id):
    """
    Transforms text data and logs provenance events.

    Args:
        data (pd.Series): The text column from the dataset.
        agreement_details (dict): Agreement metadata (agreement_id, owner_spid, etc.).
        job_id (str): Unique job identifier.
        bucket_id (str): S3 bucket identifier.
        output_bucket_id (str): The bucket where transformed data is stored.
        pipeline_id (str): Unique pipeline identifier.

    Returns:
        pd.Series: Transformed text data.
    """
    event_id_start = str(uuid.uuid4())
    timestamp_created = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

    # Log transformation start
    log_provenance_event({
        "record_id": event_id_start,
        "timestamp_created": timestamp_created,
        "record_type": "DataPrep",
        "record_status": "Active",
        "processing_map": {
            "pipeline_id": pipeline_id,
            "operation_sequence": "start",
            "applied_rules": "None",
            "validation_steps": "None",
            "error_handling_config": "None",
            "processing_status": "Started",
            "output_format": "None",
            "quality_metrics": "None"
        }
    })

    # Apply transformations
    transformations_applied = ["lowercase", "remove_punctuation"]
    transformed_data = data.str.lower().str.replace(r"[.,!?]", "", regex=True)

    time.sleep(2)  # Simulate processing time

    # Log transformation completion
    event_id_completed = str(uuid.uuid4())
    timestamp_completed = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    log_provenance_event({
        "record_id": event_id_completed,
        "timestamp_created": timestamp_completed,  
        "record_type": "DataPrep",
        "record_status": "Active",
        "processing_map": {
            "pipeline_id": pipeline_id,
            "operation_sequence": "completed",
            "applied_rules": ",".join(transformations_applied),
            "validation_steps": "None",
            "error_handling_config": "None",
            "processing_status": "Completed",
            "output_format": "Processed Text",
            "quality_metrics": "None",
            "linkedTo": event_id_start
        }
    })

    return transformed_data
