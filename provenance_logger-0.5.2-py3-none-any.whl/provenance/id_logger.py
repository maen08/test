from datetime import datetime
from typing import Optional, List, Literal, Union, Dict, Any
from pydantic import BaseModel
from neo4j import GraphDatabase

# Neo4j connection settings
NEO4J_URI = "bolt://ec2-18-133-186-21.eu-west-2.compute.amazonaws.com:7687"
NEO4J_USER = "neo4j"
NEO4J_PASSWORD = "c1pd3moproject"

# schemas for ID Nodes
class ServiceProvider(BaseModel):
    spid: str
    name: str
    type: Literal["Content Owner", "Data Prep Service", "Model Builder"]
    registration_timestamp: datetime
    sha256: str
    status: str
    description: str
    org_page_url: str
    federated_registry_url: str
    service_registry_url: str

class ServiceAsset(BaseModel):
    said: str
    name: str
    type: str
    url: str
    registration_timestamp: datetime
    sha256: str
    status: str
    description: str
    federated_registry_url: str

class ServiceComponent(BaseModel):
    scid: str
    name: str
    registration_timestamp: datetime
    sha256: str
    status: str
    description: str
    job_page_url: str
    service_registry_url: str

class ServiceSchedule(BaseModel):
    ssid: str
    name: str
    registration_timestamp: datetime
    sha256: str
    status: str
    description: str
    service_registry_url: str

class Agreement(BaseModel):
    agreement_id: str
    parent_agreement_id: Optional[str]
    sha256: str
    version: float
    status: str
    created_at: datetime
    updated_at: Optional[datetime]
    derivated_asset_expiration_date: Optional[datetime]
    existing_license: Optional[str]
    job_price: Optional[Union[int|float]]
    revenue_split_type: str
    first_party_share: float
    second_party_share: float
    sow_id: str

class StatementOfWork(BaseModel):
    sow_id: str
    version: float
    sha256: str
    status: str
    spid: str
    subprocessors: Optional[Dict[str, Any]]
    destination_said: str
    created_at: datetime
    updated_at: Optional[datetime]
    deadline: datetime
    description: str
    requirements: str

class Neo4jLogger:
    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))

    def close(self):
        self.driver.close()

    def log_service_provider(self, provider: ServiceProvider):
        query = """
        MERGE (sp:ServiceProvider {spid: $spid})
        ON CREATE SET sp.name = $name, sp.type = $type, sp.registration_timestamp = $registration_timestamp,
                      sp.status = $status, sp.description = $description, sp.org_page_url = $org_page_url,
                      sp.federated_registry_url = $federated_registry_url, sp.service_registry_url = $service_registry_url
        """
        self._execute_query(query, provider.model_dump())

    def log_service_asset(self, asset: ServiceAsset):
        query = """
        MERGE (sa:ServiceAsset {said: $said})
        ON CREATE SET sa.name = $name, sa.type = $type, sa.url = $url, sa.registration_timestamp = $registration_timestamp,
                      sa.status = $status, sa.description = $description, sa.federated_registry_url = $federated_registry_url
        """
        self._execute_query(query, asset.model_dump())

    def log_service_component(self, component: ServiceComponent):
        query = """
        MERGE (sc:ServiceComponent {scid: $scid})
        ON CREATE SET sc.name = $name, sc.registration_timestamp = $registration_timestamp, sc.status = $status,
                      sc.description = $description, sc.job_page_url = $job_page_url, sc.service_registry_url = $service_registry_url
        """
        self._execute_query(query, component.model_dump())

    def log_service_schedule(self, schedule: ServiceSchedule):
        query = """
        MERGE (ss:ServiceSchedule {ssid: $ssid})
        ON CREATE SET ss.name = $name, ss.registration_timestamp = $registration_timestamp, ss.status = $status,
                      ss.description = $description, ss.service_registry_url = $service_registry_url
        """
        self._execute_query(query, schedule.model_dump())

    def log_Agreement(self, schedule: Agreement):
        query = """
        MERGE (a:Agreement {agreement_id: $agreement_id})
        ON CREATE SET a.agreement_id = $agreement_id, a.parent_agreement_id = $parent_agreement_id, a.sha256 = $sha256,
                      a.version = $version, a.status = $status, a.created_at = $created_at, a.updated_at = $updated_at, 
                      a.derivated_asset_expiration_date = $derivated_asset_expiration_date, a.existing_license = $existing_license, 
                      a.job_price = $job_price, a.revenue_split_type = $revenue_split_type, a.first_party_share = $first_party_share,
                      a.second_party_share = $second_party_share, a.sow_id = $sow_id
        WITH a
        MATCH (s:StatementOfWork {sow_id: $sow_id})
        MERGE (a)-[:CONTAINS]->(s)
        """
        self._execute_query(query, schedule.model_dump())
    
    def log_StatementOfWork(self, schedule: StatementOfWork):
        query = """
        MERGE (s:StatementofWork {sow_id: $sow_id})
        ON CREATE SET s.version = $version, s.status = $status, s.spid = $spid,
                      s.subprocessors = $subprocessors, s.destination_said = $destination_said,
                      s.created_at = $created_at, s.updated_at = $updated_at, s.deadline = $deadline,
                      s.description = $description, s.requirements = $requirements
        WITH s
        MATCH (a:Agreement {sow_id: $sow_id})
        MERGE (a)-[:CONTAINS]->(s)
        """
        self._execute_query(query, schedule.model_dump())

    def _execute_query(self, query, parameters):
        with self.driver.session() as session:
            session.run(query, parameters)

# Logger instance
_logger = Neo4jLogger(NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD)

def log_id(id: BaseModel):
    """Function to log different ID node events dynamically."""
    if isinstance(id, ServiceProvider):
        _logger.log_service_provider(id)
    elif isinstance(id, ServiceAsset):
        _logger.log_service_asset(id)
    elif isinstance(id, ServiceComponent):
        _logger.log_service_component(id)
    elif isinstance(id, ServiceSchedule):
        _logger.log_service_schedule(id)
    elif isinstance(id, Agreement):
        _logger.log_Agreement(id)
    elif isinstance(id, StatementOfWork):
        _logger.log_StatementOfWork(id)
    else:
        raise ValueError(f"Unsupported event type: {type(id)}")

def close_logger():
    """Close the Neo4j connection when the system shuts down."""
    _logger.close()

